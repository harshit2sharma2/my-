
from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///chatbot.db'  # SQLite configuration
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

class ChatHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# Initialize Database
with app.app_context():
    db.create_all()

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register_user():
    data = request.json
    name, email = data.get('name'), data.get('email')
    if not name or not email:
        return jsonify({'error': 'Name and email are required!'}), 400

    user = User(name=name, email=email)
    db.session.add(user)
    db.session.commit()
    return jsonify({'message': 'User registered successfully!', 'user_id': user.id}), 201

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    user_id, message = data.get('user_id'), data.get('message')

    if not user_id or not message:
        return jsonify({'error': 'User ID and message are required!'}), 400

    # Simple response logic (replace with AI/NLP if needed)
    response = f"You said: {message}"

    # Save chat history
    chat = ChatHistory(user_id=user_id, message=message, response=response)
    db.session.add(chat)
    db.session.commit()

    return jsonify({'response': response, 'timestamp': chat.timestamp}), 200

@app.route('/history/<int:user_id>', methods=['GET'])
def chat_history(user_id):
    history = ChatHistory.query.filter_by(user_id=user_id).all()
    return jsonify([
        {'message': chat.message, 'response': chat.response, 'timestamp': chat.timestamp}
        for chat in history
    ])

if __name__ == '__main__':
    app.run(debug=True)
